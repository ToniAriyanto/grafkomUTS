import Engine.*;
import Engine.Object;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.glClearColor;
import static org.lwjgl.opengl.GL30.*;

public class Main {
    private Window window =
            new Window
    (1500,1000,"Hello World");
    private ArrayList<Object> objects
            = new ArrayList<>();
    private ArrayList<Object> objectsRectangle
            = new ArrayList<>();

    private ArrayList<Object> objectAlvin
            = new ArrayList<>();

    private ArrayList<Object> objectHans
            = new ArrayList<>();

    private ArrayList<Object> environment = new ArrayList<>();

    private ArrayList<Object> objectsPointsControl
            = new ArrayList<>();

    private MouseInput mouseInput;
    int countDegree = 0;

    Projection projection = new Projection(window.getWidth(),window.getHeight());

    Camera camera = new Camera();
    public void init() {
        window.init();
        GL.createCapabilities();
        mouseInput = window.getMouseInput();
        camera.setPosition(0, 0, 1);
//        camera.setRotation((float) Math.toRadians(0.0f), (float) Math.toRadians(-15.0f));
        //code
//        objects.add(new Object2d(
//            Arrays.asList(
//                //shaderFile lokasi menyesuaikan objectnya
//                new ShaderProgram.ShaderModuleData
//                ("resources/shaders/scene.vert"
//                , GL_VERTEX_SHADER),
//                new ShaderProgram.ShaderModuleData
//                ("resources/shaders/scene.frag"
//                , GL_FRAGMENT_SHADER)
//            ),
//            new ArrayList<>(
//                List.of(
//                    new Vector3f(0.0f,0.5f,0.0f),
//                    new Vector3f(-0.5f,-0.5f,0.0f),
//                    new Vector3f(0.5f,-0.5f,0.0f)
//                )
//            ),
//            new Vector4f(0.0f,1.0f,1.0f,1.0f)
//        ));
//        objects.add(new Object(
//            Arrays.asList(
//                //shaderFile lokasi menyesuaikan objectnya
//                new ShaderProgram.ShaderModuleData
//                ("resources/shaders/" +
//                    "sceneWithVerticesColor.vert"
//                        , GL_VERTEX_SHADER),
//                new ShaderProgram.ShaderModuleData
//                    ("resources/shaders/" +
//                    "sceneWithVerticesColor.frag"
//                            , GL_FRAGMENT_SHADER)
//        ),
//        new ArrayList<>(
//                List.of(
//                    new Vector3f(0.0f,0.5f,0.0f),
//                    new Vector3f(-0.5f,-0.5f,0.0f),
//                    new Vector3f(0.5f,-0.5f,0.0f)
//                )
//            ),
//        new ArrayList<>(
//            List.of(
//                new Vector3f(1.0f,0.0f,0.0f),
//                new Vector3f(0.0f,1.0f,0.0f),
//                new Vector3f(0.0f,0.0f,1.0f)
//            )
//        )
//        ));
//        objectsRectangle.add(new Rectangle(
//            Arrays.asList(
//                //shaderFile lokasi menyesuaikan objectnya
//                new ShaderProgram.ShaderModuleData
//                ("resources/shaders/scene.vert"
//                , GL_VERTEX_SHADER),
//                new ShaderProgram.ShaderModuleData
//                ("resources/shaders/scene.frag"
//                , GL_FRAGMENT_SHADER)
//            ),
//            new ArrayList<>(
//                List.of(
//                    new Vector3f(0.0f,0.0f,0.0f),
//                    new Vector3f(0.5f,0.0f,0.0f),
//                    new Vector3f(0.0f,0.5f,0.0f),
//                    new Vector3f( 0.5f,0.5f,0.0f)
//                )
//            ),
//            new Vector4f(0.0f,1.0f,1.0f,1.0f),
//            Arrays.asList(0,1,2,1,2,3)
//
//        ));
//        objectsPointsControl.add(new Object(
//            Arrays.asList(
//                //shaderFile lokasi menyesuaikan objectnya
//                new ShaderProgram.ShaderModuleData
//                ("resources/shaders/scene.vert"
//                , GL_VERTEX_SHADER),
//                new ShaderProgram.ShaderModuleData
//                ("resources/shaders/scene.frag"
//                , GL_FRAGMENT_SHADER)
//            ),
//            new ArrayList<>(),
//            new Vector4f(0.0f,1.0f,1.0f,1.0f)
//        ));
//        objects.add(new Cuboid(
//                Arrays.asList(
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
//                ),
//                new ArrayList<>(),
//                new Vector4f(0.0f,1.0f,0.0f,1.0f),
//                Arrays.asList(0.0f,0.0f,0.0f),
//                0.125f,
//                0.125f,
//                0.125f,
//                36,
//                18
//        ));
////        objects.get(0).translateObject(0.5f,0.0f,0.0f);
//        objects.get(0).scaleObject(2f,2f,2f);
//
//        objects.get(0).getChildObject().add(new Sphere(
//                Arrays.asList(
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
//                ),
//                new ArrayList<>(),
//                new Vector4f(0.0f,1.0f,0.0f,1.0f),
//                Arrays.asList(0.0f,0.0f,0.0f),
//                0.125f,
//                0.125f,
//                0.125f,
//                36,
//                18
//        ));
//        objects.get(0).getChildObject().get(0).translateObject(0.25f,0.0f,0.0f);
////        objects.get(0).getChildObject().get(0).setCenterPoint(Arrays.asList(0.25f,0.0f,0.0f));
//
//        objects.get(0).getChildObject().add(new Cylinder(
////                Arrays.asList(
////                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
////                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
////                ),
////                new ArrayList<>(),
////                new Vector4f(0.0f,1.0f,1.0f,1.0f),
////                Arrays.asList(0.0f,0.0f,0.0f),
////                0.125f,
////                0.125f,
////                0.125f,
////                36,
////                18
////        ));
//        objects.get(0).getChildObject().get(1).translateObject(0.5f,0.0f,0.0f);
//        objects.get(0).getChildObject().get(1).scaleObject(0.5f,0.5f,0.5f);
////        objects.get(0).getChildObject().get(1).setCenterPoint(Arrays.asList(0.5f,0.0f,0.0f));
//
//        objects.get(0).getChildObject().get(1).getChildObject().add(new Sphere(
//                Arrays.asList(
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
//                ),
//                new ArrayList<>(),
//                new Vector4f(0.0f,1.0f,0.0f,1.0f),
//                Arrays.asList(0.0f,0.0f,0.0f),
//                0.125f,
//                0.125f,
//                0.125f,
//                36,
//                18
//        ));
//        objects.get(0).getChildObject().get(1).getChildObject().get(0).scaleObject(0.5f,0.5f,0.5f);
//        objects.get(0).getChildObject().get(1).getChildObject().get(0).translateObject(0.5f,-0.1f,0.0f);
//        objects.get(0).getChildObject().get(1).getChildObject().get(0).setCenterPoint(Arrays.asList(0.5f,-0.1f,0.0f));

//        environment.add(new Cuboid(
//                Arrays.asList(
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
//                ),
//                new ArrayList<>(),
//                new Vector4f(0.0f, 1.0f, 0.0f, 1.0f),
//                Arrays.asList(0f,0.5f,-0.5f),
//                0.25f,
//                0.25f,
//                0.25f,
//                36,
//                18
//        ));

//        objectAlvin.add(new Sphere(
//                Arrays.asList(
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
//                ),
//                new ArrayList<>(),
//                new Vector4f(0.0f,1.0f,0.0f,1.0f),
//                Arrays.asList(0.0f,0.0f,0.0f),
//                0.125f,
//                0.125f,
//                0.125f,
//                36,
//                18
//        ));

//        objectHans.add(new Sphere(
//                Arrays.asList(
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
//                ),
//                new ArrayList<>(),
//                new Vector4f(0.0f,1.0f,0.0f,1.0f),
//                Arrays.asList(0.0f,0.25f,0.0f),
//                0.15f,
//                0.15f,
//                0.15f,
//                36,
//                18
//        ));
//
//        objectHans.add(new Cuboid(
//                Arrays.asList(
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
//                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
//                ),
//                new ArrayList<>(),
//                new Vector4f(0.0f, 1.0f, 0.0f, 1.0f),
//                Arrays.asList(0f,-0.125f,0f),
//                0.25f,
//                0.5f,
//                0.2f,
//                36,
//                18
//        ));

        objectHans.add(new Cylinder(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(0.0f,1.0f,1.0f,1.0f),
                Arrays.asList(0.0f,-0.375f,0.0f),
                0.125f,
                0.125f,
                0.125f,
                36,
                18,0.3f
        ));


    }

    public void input() {
        if (window.isKeyPressed(GLFW_KEY_W)) {
            countDegree++;
            //rotasi terhadap matahari
            objectHans.get(0).rotateObject((float) Math.toRadians(0.5f),0.0f,1.0f,0.0f);
//            for(Object child:objects.get(0).getChildObject()){
//                List<Float> temp = new ArrayList<>(child.getCenterPoint());
//                //rotasi terhadap sumbu masing-masing planet
//                child.translateObject(temp.get(0)*-1,temp.get(1)*-1,temp.get(2)*-1);
//                child.rotateObject((float) Math.toRadians(0.5f),0.0f,1.0f,0.0f);
//                child.translateObject(temp.get(0)*1,temp.get(1)*1,temp.get(2)*1);
//                for(Object y:objects.get(0).getChildObject().get(1).getChildObject()){
//                    //rotasi terhadap bumi
//                    List<Float> temp1 = new ArrayList<>(objects.get(0).getChildObject().get(1).getCenterPoint());
//                    y.translateObject(temp1.get(0)*-1,temp1.get(1)*-1,temp1.get(2)*-1);
//                    y.rotateObject((float) Math.toRadians(0.5f),0.0f,1.0f,0.0f);
//                    y.translateObject(temp1.get(0)*1,temp1.get(1)*1,temp1.get(2)*1);
//                    //rotasi terhadap sumbunya sendiri
//                    temp1 = new ArrayList<>(objects.get(0).getChildObject().get(1).getChildObject().get(0).getCenterPoint());
//                    y.translateObject(temp1.get(0)*-1,temp1.get(1)*-1,temp1.get(2)*-1);
//                    y.rotateObject((float) Math.toRadians(0.5f),0.0f,1.0f,1.0f);
//                    y.translateObject(temp1.get(0)*1,temp1.get(1)*1,temp1.get(2)*1);
//                }
//                child.rotateObject((float) Math.toRadians(0.5f),0.0f,1.0f,1.0f);
//            }
        }
//
//        if(mouseInput.isLeftButtonPressed()){
//            Vector2f pos = mouseInput.getCurrentPos();
//            pos.x = (pos.x - (window.getWidth())/2.0f) / (window.getWidth()/2.0f);
//            pos.y = (pos.y - (window.getHeight())/2.0f) / (-window.getHeight()/2.0f);
//
//            // Check if the mouse is within the bounds of the screen
//            if((!(pos.x > 1 || pos.x < -0.97) && !(pos.y > 0.97 || pos.y < -1))){
//
//                // Get the center point of the first object
//                List<Float> centerPoint = objects.get(0).getCenterPoint();
//
//                // Calculate the translation offset based on the mouse position
//                float dx = pos.x - centerPoint.get(0);
//                float dy = pos.y - centerPoint.get(1);
//
//                // Translate the object by the offset
//                objects.get(0).translateObject(dx, dy, 0F);
//
//                // You can also apply the translation to the child objects if necessary
//                // for(Object child : objects.get(0).getChildObject()){
//                //     child.translateObject(dx, dy, 0);
//                // }
//            }
//        }
//        if (window.isKeyPressed(GLFW_KEY_T)) {
//            // Get the center point of the first object
//            List<Float> centerPoint = objects.get(0).getCenterPoint();
//
//            // Translate the object by a fixed amount
//            float dx = 0.001F;
//            float dy = 0.001F;
//
//            // Translate the object by the offset
//            objects.get(0).translateObject(dx, dy, 0F);
//
//            // You can also apply the translation to the child objects if necessary
//            // for(Object child : objects.get(0).getChildObject()){
//            //     child.translateObject(dx, dy, 0);
//            // }
//        }
//        if (window.isKeyPressed(GLFW_KEY_R)) {
//            // Get the first object in the list
//            Object objectToRotate = objects.get(0);
//
//            float angle = 0.1F;  // in radians
//            float axisX = 0.0F;
//            float axisY = 0.0F;
//            float axisZ = 1.0F;
//
//
//            // Apply the rotation to the object
//            objectToRotate.rotateObject(angle, axisX, axisY, axisZ);
//
//            // You can also apply the rotation to the child objects if necessary
//            // for(Object child : objectToRotate.getChildObject()){
//            //     child.rotateObject(angle, axisX, axisY, axisZ);
//            // }
//        }
//        if (window.isKeyPressed(GLFW_KEY_S)) {
//            // Get the first object in the list
//            Object objectToRotate = objects.get(0);
//
//            // Define the rotation angle and axis
//            float angle = 0.05F;  // in radians
//            float axisX = 0.0F;
//            float axisY = 0.0F;
//            float axisZ = 1.0F;
//
//            // Apply the rotation to the object
//            objectToRotate.rotateObject(angle, axisX, axisY, axisZ);
//
//            // You can also apply the rotation to the child objects if necessary
//            // for(Object child : objectToRotate.getChildObject()){
//            //     child.rotateObject(angle, axisX, axisY, axisZ);
//            // }
//        }



//
//        if(mouseInput.isLeftButtonPressed()){
//            Vector2f pos = mouseInput.getCurrentPos();
////            System.out.println("x : "+pos.x+" y : "+pos.y);
//            pos.x = (pos.x - (window.getWidth())/2.0f) /
//                    (window.getWidth()/2.0f);
//            pos.y = (pos.y - (window.getHeight())/2.0f) /
//                    (-window.getHeight()/2.0f);
//            //System.out.println("x : "+pos.x+" y : "+pos.y);
//
//            if((!(pos.x > 1 || pos.x < -0.97) && !(pos.y > 0.97 || pos.y < -1))){
//                System.out.println("x : "+pos.x+" y : "+pos.y);
////                objectsPointsControl.get(0).addVertices(new Vector3f(pos.x,pos.y,0));
//
//            }
//        }

    }
    public void loop(){
        while (window.isOpen()) {
            window.update();
            glClearColor(0.02f,
                    0.15f, 1.0f,
                    0.0f);
            GL.createCapabilities();
            input();

            //code
            for(Object object: objects){
                object.draw(camera,projection);
            }
            for(Object object: objectsRectangle){
                object.draw(camera,projection);
            }
//            for(Object object: objectsPointsControl){
//                object.drawLine();
//            }
            for(Object object: environment){
                object.draw(camera,projection);
            }

            for(Object object: objectHans){
                object.draw(camera,projection);
            }

            // Restore state
            glDisableVertexAttribArray(0);

            // Poll for window events.
            // The key callback above will only be
            // invoked during this call.
            glfwPollEvents();

        }
    }
    public void run() {

        init();
        loop();

        // Terminate GLFW and
        // free the error callback
        glfwTerminate();
        glfwSetErrorCallback(null).free();
    }
    public static void main(String[] args) {
        new Main().run();
    }
}